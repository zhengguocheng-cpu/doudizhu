# CardService - 扑克牌服务模块

## 📖 概述

CardService是斗地主游戏的核心服务模块，负责所有与扑克牌相关的操作。采用模块化设计，将原本在GameService中的扑克牌逻辑拆分到独立的服务中。

## 🏗️ 架构设计

```
card/
├── cardGenerator.ts   # 扑克牌生成器
├── cardShuffler.ts    # 洗牌算法服务
├── cardValidator.ts   # 牌型验证器
├── cardService.ts     # 主要服务接口
└── example.ts         # 使用示例
```

## 🎯 核心功能

### **CardGenerator** - 扑克牌生成器
- ✅ 生成标准54张扑克牌（含大小王）
- ✅ 支持自定义牌数生成
- ✅ 提供友好显示名称转换
- ✅ 字符串与Card对象互转

### **CardShuffler** - 洗牌算法服务
- ✅ Fisher-Yates标准洗牌算法
- ✅ 多次洗牌增加随机性
- ✅ 切牌+洗牌模拟真实操作
- ✅ 洗牌公平性验证工具

### **CardValidator** - 牌型验证器
- ✅ 出牌合法性验证
- ✅ 玩家手牌检查
- ✅ 房间玩家数量验证
- ✅ 游戏开始条件验证

### **CardService** - 主要服务接口
- ✅ 智能发牌（17张手牌+3张底牌）
- ✅ 出牌验证API
- ✅ 牌面友好显示
- ✅ 洗牌公平性测试

## 🚀 使用方法

### **基本发牌**
```typescript
import { cardService } from './services/card/cardService';

// 为3个玩家发牌
const result = cardService.dealCards(3);
console.log(`玩家1: ${result.playerCards[0].length}张牌`);
console.log(`底牌: ${result.bottomCards.length}张牌`);
```

### **出牌验证**
```typescript
// 验证玩家是否可以出这些牌
const validation = cardService.validatePlay(playerCards, playedCards);
if (validation.valid) {
  console.log('出牌有效');
} else {
  console.log('出牌无效:', validation.error);
}
```

### **友好显示**
```typescript
// 将扑克牌转换为友好显示格式
const displayNames = cardService.getCardsDisplayNames(['heartsA', 'spadesK']);
console.log(displayNames); // ['♥A', '♠K']
```

## 📊 性能特性

- **洗牌算法**: O(n)时间复杂度，O(1)空间复杂度
- **发牌算法**: 自动分配，公平随机
- **验证算法**: O(n)线性验证速度
- **内存优化**: 避免重复创建牌实例

## 🧪 测试覆盖

CardService包含完整的使用示例和公平性验证：

```typescript
// 运行公平性测试
const isFair = cardService.validateShuffleFairness(1000);
console.log(`洗牌算法是否公平: ${isFair}`);
```

## 🔧 API接口

### **HTTP API**
```http
POST /api/games/rooms/{roomId}/validate-play
Content-Type: application/json

{
  "playerId": "player123",
  "cards": ["hearts3", "hearts4", "hearts5"]
}
```

**响应格式**:
```json
{
  "success": true,
  "message": "出牌有效"
}
```

## 💡 设计优势

1. **单一职责**: 每个子服务专注于特定功能
2. **高内聚**: 扑克牌相关操作集中管理
3. **易测试**: 独立模块便于单元测试
4. **可扩展**: 支持未来添加更多牌型规则
5. **性能优化**: 专用算法，执行效率高

## 🔄 迁移说明

从GameService迁移到CardService的改动：

**之前**:
```typescript
// 在GameService中
private generateCards(): Card[] { /* 150行代码 */ }
private shuffleCards(cards: Card[]): void { /* 洗牌逻辑 */ }
```

**现在**:
```typescript
// 使用CardService
const dealResult = cardService.dealCards(playerCount);
player.cards = dealResult.playerCards[index];
```

## 🎮 实际应用

在斗地主游戏中的使用场景：

1. **游戏开始**: 自动发牌给所有玩家
2. **出牌阶段**: 验证玩家出牌合法性
3. **显示界面**: 提供友好的牌面显示
4. **规则检查**: 确保游戏按规则进行

---

**CardService让扑克牌操作变得简单、高效和可靠！** 🎯
